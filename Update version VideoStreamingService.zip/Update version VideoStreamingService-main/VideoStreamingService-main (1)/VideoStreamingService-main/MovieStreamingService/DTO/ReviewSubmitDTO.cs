﻿namespace MovieStreamingService.DTO
{
    public class ReviewSubmitDTO
    {
        public string rating { get; set; }
        public string review { get; set; }
        public string title { get; set; }
        public string movieId { get; set; }
    }
}
